@FunctionalInterface
interface Formater {
    String format(Book b);
}
