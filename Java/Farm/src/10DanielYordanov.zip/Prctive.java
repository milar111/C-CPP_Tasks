public interface Prctive {
    double dailyProduction();
    String productUnit();
}
