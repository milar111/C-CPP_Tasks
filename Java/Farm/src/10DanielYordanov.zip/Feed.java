public interface Feed {
    void feed(double kgOfFeed);
}
