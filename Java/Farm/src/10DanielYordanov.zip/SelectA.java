@FunctionalInterface
public interface SelectA {
    boolean test(Animal a);
}
